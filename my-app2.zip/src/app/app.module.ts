import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { UserService } from './shared/user.service';
import { DepartmentService } from './shared/department.service';
import { FormsModule } from '@angular/forms';
import { CalcComponent } from './components/calc/calc.component';

@NgModule({
  // it contains all the components,Pipes and Directives
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
    CalcComponent
  ],
  // contains all the angular modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  // contains Services
  providers: [],
  // loads the welcome component
  bootstrap: [AppComponent]
})
export class AppModule { }
