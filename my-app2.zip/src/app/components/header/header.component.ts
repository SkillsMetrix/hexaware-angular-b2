import { Component } from '@angular/core';
import { UserService } from '../../shared/user.service';
import { DepartmentService } from '../../shared/department.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {

  constructor(private us:UserService,private dept:DepartmentService){
    this.users=this.us.loadUsers()
    this.depts=this.dept.loadDepts()
  }

  users
  depts

}
