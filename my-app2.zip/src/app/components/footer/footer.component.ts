import { Component, Input } from '@angular/core';
import { UserService } from '../../shared/user.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css',
})

export class FooterComponent {
  constructor(private lp:UserService){
    this.people=this.lp.loadPeople()
  }
  @Input()
  mycity = 'NY';
  @Input()
  pp =
    'https://plus.unsplash.com/premium_photo-1689568126014-06fea9d5d341?ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8cHJvZmlsZXxlbnwwfHwwfHx8MA%3D%3D&fm=jpg&q=60&w=3000';
  addUser() {
    alert('user added');
  }
  people:any[]=[]
  getColor(country: string) {
    switch (country) {
      case 'Australia':
        return 'blue';
      case 'USA':
        return 'green';
      case 'India':
        return 'purple';
      default:
        return null;
    }
  }
}
