import { Component, OnInit } from '@angular/core';
import { UserformserviceService } from '../../shared/userformservice.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { EdituserComponent } from '../edituser/edituser.component';

@Component({
  selector: 'app-loadusers',
  templateUrl: './loadusers.component.html',
  styleUrl: './loadusers.component.css'
})
export class LoadusersComponent implements OnInit{

  constructor(private us:UserformserviceService,private sb:MatSnackBar,private dialog:MatDialog){}

  ngOnInit(): void {
    this.loadUsers()
  }
  displayColumns:string[]=['uname','email','city','actions']
  users:any
  loadUsers(){
    this.us.loadUserFromDB().subscribe({
      next: (res) => (this.users=res)
      
    })
  }
  deleteUser(id):void{
    const ok= window.confirm(`Delete user ${id} ?`)
    if(!ok) return
    this.us.deleteUser(id).subscribe({
      next :() => {
        this.sb.open('Record Deleted..!','Close',{duration:2200})
        this.loadUsers()
      }
    })
  }
editUser(id):void{
  const ref= this.dialog.open(EdituserComponent,{
    width:'380px',
    data: {...this.users}
  })
  ref.afterClosed().subscribe(result => {
    if(result){
      this.us.updateUser(id,result).subscribe({
        next:()=> {
          this.sb.open('Record Updated', 'Close',{duration:2200})
        }
      })
    }
  })
}
}
