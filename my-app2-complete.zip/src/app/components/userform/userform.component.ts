import { Component } from '@angular/core';
import { UserformserviceService } from '../../shared/userformservice.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-userform',
  templateUrl: './userform.component.html',
  styleUrl: './userform.component.css'
})
export class UserformComponent {

  constructor(private us:UserformserviceService){}

  addUser(nf:NgForm){
     
    
    this.us.addUserToDB(nf.value)
  }

}
