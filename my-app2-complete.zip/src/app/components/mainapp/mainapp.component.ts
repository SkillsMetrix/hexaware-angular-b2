import { Component, ViewChild } from '@angular/core';
import { CalcComponent } from '../calc/calc.component';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html',
  styleUrl: './mainapp.component.css'
})
export class MainappComponent {

  shopCart=['soap','watches']

  newcity='mumbai'
  @ViewChild(CalcComponent)
  private calc={} as CalcComponent

  inc(){
    this.calc.increment()
  }
  dec(){
    this.calc.decrement()
  }

}
