import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CalcComponent } from './components/calc/calc.component';
import { UserformComponent } from './components/userform/userform.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MaterialModule } from './material/material.module';
import { DdComponent } from './components/dd/dd.component';
import { HttpClientModule } from '@angular/common/http';
import { LoadusersComponent } from './components/loadusers/loadusers.component';
import { EdituserComponent } from './components/edituser/edituser.component';


@NgModule({
  // it contains all the components,Pipes and Directives
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
    CalcComponent,
    UserformComponent,
    DdComponent,
    LoadusersComponent,
    EdituserComponent
  ],
  // contains all the angular modules
  imports: [
    BrowserModule,
    MaterialModule,
    AppRoutingModule,
    FormsModule,ReactiveFormsModule,
    HttpClientModule
  ],
  // contains Services
  providers: [
    provideAnimationsAsync()
  ],
  // loads the welcome component
  bootstrap: [AppComponent]
})
export class AppModule { }
