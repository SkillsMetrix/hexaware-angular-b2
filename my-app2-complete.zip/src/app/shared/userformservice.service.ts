import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserDetails } from './UserDetails';

@Injectable({
  providedIn: 'root',
})
export class UserformserviceService {
  private URL='http://localhost:3000/users'
  constructor(private http: HttpClient) {}

  addUserToDB(data: any) {
    this.http.post(this.URL,data).subscribe((data) => {
      console.log(data);
    });
  }

  loadUserFromDB() {
    return this.http.get(this.URL);
  }
  deleteUser(id):Observable<void>{
    return this.http.delete<void>(`${this.URL}/${id}`)
  }
  updateUser(id,user:Partial<UserDetails>):Observable<UserDetails>{
    return this.http.put<UserDetails>(`${this.URL}/${id}`,user)
  }
}
