import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrl: './edituser.component.css',
})
export class EdituserComponent implements OnInit {
  constructor(
    private fb: FormBuilder,
    private dr: MatDialogRef<EdituserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    this.form= this.fb.group({
      uname: [this.data.uname],
       pass: [this.data.pass],
        email: [this.data.email],
         city: [this.data.city],
    })
  }
  save(){
    console.log(this.form.value);
    
  }
  form: FormGroup;
  ngOnInit(): void {
    if (this.data) {
      this.form.patchValue({
        uname: this.uname,
        pass: this.pass,
        email: this.email,
        city: this.city,
      });
      console.log(this.form.value);
    }
  }
  myForm!: FormGroup;
  uname!: FormControl;
  pass!: FormControl;
  email!: FormControl;
  city!: FormControl;
}
