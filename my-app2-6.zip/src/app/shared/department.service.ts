import { Injectable } from "@angular/core";

@Injectable(
    {
        providedIn:'root'
    }
)
export class DepartmentService {

    loadDepts():string[]{
        return ['HR','Finance','IT']
    }
}