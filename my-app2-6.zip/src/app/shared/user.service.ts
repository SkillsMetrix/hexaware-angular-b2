import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  loadUsers(): string[] {
    return ['admin', 'manager', 'qa'];
  }
  loadPeople(): any[] {
    return [
      {
        name: 'Adam',
        country: 'Australia',
      },
      {
        name: 'Sam',
        country: 'USA',
      },
      {
        name: 'Chitra',
        country: 'India',
      },
    ];
  }
}
