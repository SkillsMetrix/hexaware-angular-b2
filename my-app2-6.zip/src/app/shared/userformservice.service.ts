import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserformserviceService {

  constructor() { }

  addUserToDB(data:any){
    console.log(data);
    
  }
}
