import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainappComponent } from './components/mainapp/mainapp.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
 
import { FormsModule } from '@angular/forms';
import { CalcComponent } from './components/calc/calc.component';
import { UserformComponent } from './components/userform/userform.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MaterialModule } from './material/material.module';


@NgModule({
  // it contains all the components,Pipes and Directives
  declarations: [
    AppComponent,
    MainappComponent,
    HeaderComponent,
    FooterComponent,
    CalcComponent,
    UserformComponent
  ],
  // contains all the angular modules
  imports: [
    BrowserModule,
    MaterialModule,
    AppRoutingModule,
    FormsModule
  ],
  // contains Services
  providers: [
    provideAnimationsAsync()
  ],
  // loads the welcome component
  bootstrap: [AppComponent]
})
export class AppModule { }
