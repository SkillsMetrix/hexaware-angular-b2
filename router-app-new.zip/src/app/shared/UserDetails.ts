export class UserDetails {
  constructor(
    public uname: string,
    public pass: string,
    public email: string,
    public city: string
  ) {}
}
