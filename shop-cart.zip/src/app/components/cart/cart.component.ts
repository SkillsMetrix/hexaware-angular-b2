import { Component, OnInit } from '@angular/core';
import { CartService } from '../../shared/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {

  constructor(private cs:CartService){}
  public products:any=[]
  public grandTotal !:number

  ngOnInit(): void {
      this.cs.getProducts()
      .subscribe(res=>{
        this.products=res
        this.grandTotal= this.cs.getTotalPrice()
      })
  }

}
