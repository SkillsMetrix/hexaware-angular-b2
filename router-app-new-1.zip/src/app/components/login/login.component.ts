import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { Router } from '@angular/router';
import { AppGuard } from '../../shared/guard.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent {
  myForm!: FormGroup;
  uname!: FormControl;
  pass!: FormControl;

  createForm() {
    this.myForm = new FormGroup({
      uname: this.uname,
      pass: this.pass,
    });
  }
  createFormControl() {
    this.uname = new FormControl('', Validators.required);
    this.pass = new FormControl('', [Validators.required]);
  }
  constructor(private route: Router,private guard:AppGuard) {
    this.createFormControl();
    this.createForm();
  }
  login() {
    this.guard.isAllowed=true
    this.route.navigateByUrl('/userdetails');
  }
}
