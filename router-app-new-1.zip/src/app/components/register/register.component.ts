import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
 import { MatSnackBar } from '@angular/material/snack-bar';
import { ValidationMessages } from '../../shared/error-messages';
import { UserformserviceService } from '../../shared/userformservice.service';
import { Router } from '@angular/router';
 
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  myForm!:FormGroup
  uname!: FormControl
  pass!: FormControl
  email!: FormControl
  city!: FormControl

  createForm(){
    this.myForm= new FormGroup({
      uname:this.uname,
      pass: this.pass,
      email:this.email,
      city:this.city
    })
  }
  createFormControl(){
    this.uname= new FormControl('',Validators.required)
        this.pass= new FormControl('',[Validators.required,Validators.minLength(6)])
            this.email= new FormControl('',[this.emailDomainValidator])
                this.city= new FormControl('')
  }
constructor(private sb:MatSnackBar,private us:UserformserviceService,private route:Router){
  this.createFormControl()
  this.createForm()
}
  addUser(){
     this.sb.open('Record Saved...!', 'close',{
      duration: 3000,
      horizontalPosition:'center',
      verticalPosition:'top',
      panelClass: ['success-snackbar']
     })
   this.us.addUserToDB(this.myForm.value)
    this.route.navigateByUrl('/login')
  }

  getErrorMessage(controlName: string):string | null{
    const control= this.myForm.get(controlName)
    if( control && control.errors){
      const errors= control.errors
      for( const errorName in errors){
        if(ValidationMessages[controlName][errorName]){
          return ValidationMessages[controlName][errorName]
        }
      }
    }
    return null
  }
  emailDomainValidator(control:FormControl){
    let email= control.value
    if(email && email.indexOf('@') !=-1){
      let [before,domain]= email.split('@')
      if(domain !='hexaware.com'){
        return {
          emailDomain:{
            pd:domain
          }
        }
      }
    }
    return null
  }


}

