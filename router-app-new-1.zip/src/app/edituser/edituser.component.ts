import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edituser',
  templateUrl: './edituser.component.html',
  styleUrl: './edituser.component.css',
})
export class EdituserComponent implements OnInit {
  ngOnInit(): void {
    if (this.data) {
      this.form.patchValue({
        uname: this.data.uname,
        pass: this.data.pass,
        email: this.data.email,
        city: this.data.city,
      });
      console.log(this.form.value);
    }
  }
  form: FormGroup;
  constructor(
    private fb: FormBuilder,
    private dr: MatDialogRef<EdituserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    console.log('Dialog Data ', this.data);

    this.form = this.fb.group({
      uname: [this.data.uname],
      pass: [this.data.pass],
      email: [this.data.email],
      city: [this.data.city],
    });
    console.log(this.form.value);
  }
  save() {
    this.dr.close(this.form.value)
  }
}
