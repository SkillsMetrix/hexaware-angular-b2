
export const ValidationMessages: {[key:string]: {[key:string]:string}}={
    uname:{
        required: 'UserName is required'

    },
    pass:{
        required: 'Password is required',
        minlength: 'password must be 6 char long'
    }
}